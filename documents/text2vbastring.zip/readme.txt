GUI program to translate plain text into a valid VBA string.

To run, just double click the .jar file, or run this command in a terminal:

java -jar /path/to/text2vbastring.jar