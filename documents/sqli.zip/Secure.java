import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Secure {

    private final static String URL = "jdbc:sqlite:sqli";

    public static void main(String[] args) throws Exception {

        System.out.println("Connecting to DB...");

        try(Connection conn = DriverManager.getConnection(URL)) {
            System.out.println("Connected to DB.");

            Scanner input = new Scanner(System.in);
            System.out.println("Enter id:");
            int id = Integer.parseInt(input.nextLine());
            System.out.println("Enter name:");
            String name = input.nextLine();
            input.close();

            PreparedStatement stmt = conn.prepareStatement("insert into users values(?,?)");
            stmt.setInt(1, id);
            stmt.setString(2, name);
            stmt.executeUpdate();
        }
        
    }
}