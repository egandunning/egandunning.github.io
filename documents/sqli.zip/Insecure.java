import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;

public class Insecure {

    private final static String URL = "jdbc:sqlite:sqli";

    public static void main(String[] args) throws Exception {

        System.out.println("Connecting to DB...");

        try(Connection conn = DriverManager.getConnection(URL)) {
            System.out.println("Connected to DB.");

            Scanner input = new Scanner(System.in);
            System.out.println("Enter id:");
            String id = input.nextLine();
            System.out.println("Enter name:");
            String name = input.nextLine();
            input.close();

            Statement stmt = conn.createStatement();

            stmt.executeUpdate("insert into users values(" + id + ",'" + name + "')");
        }
        
    }
}