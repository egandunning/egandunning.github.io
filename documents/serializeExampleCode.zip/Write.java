import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.File;

public class Write {
    public static void main(String[] args) throws Exception {

        MyObject myObject = new MyObject("Walt");

        System.out.print("Object to save: " + myObject.getName());

        FileOutputStream fs = new FileOutputStream(new File("object.obj"));
        ObjectOutputStream os = new ObjectOutputStream(fs);
        os.writeObject(myObject);
        os.close();
    }
}