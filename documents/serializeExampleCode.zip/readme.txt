To run:

open a terminal/command prompt in this directory, then type the commands listed below.

javac *.java
java Write
java Read