import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.File;

public class Read {
    public static void main(String[] args) throws Exception {
        FileInputStream fs = new FileInputStream(new File("object.obj"));
        ObjectInputStream os = new ObjectInputStream(fs);
        MyObject myObject = (MyObject)os.readObject();
        os.close();
        System.out.println("Object read from file: " + myObject.getName());
    }
}