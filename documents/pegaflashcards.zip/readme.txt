Pega Flashcards
Egan Dunning 2017
-------------------------
Contents
1. About
2. Running the program
-------------------------
1. About
This project is a command-line program that extracts key terms and their
definitions from the Pega Academy Glossary. Since this glossary is
proprietary, the user must create an account on the PDN (Pega Developer
Network). The glossary can be found by enrolling in a course on the PDN.
Start a lesson, then click the "Complete Glossary" link on the right side
of the page. The program is written for the glossary from the System
Architect Essentials course for Pega 7.2.

The purpose of this program is to allow users to easily review Pega key
terms in order to study for certification exams or job interviews.

2. Running the program
Download the glossary html document, then run 
  java -jar glossary.jar init /path/to/glossary.html

When the program finishes parsing the html, use the following command
line arguments:
  (none) - Show the list of valid arguments and thier usage.
  show - Show the complete list of key terms and their definitions.
  random - Cycle through random key terms and their definitions.
  lookup - Case insensitive definition lookup.
